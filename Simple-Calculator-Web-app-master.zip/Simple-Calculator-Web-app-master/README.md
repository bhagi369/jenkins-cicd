# A Simple Calculator Web application
A simple calculator application using HTML, CSS, Javascript. <br>
Check out the Django project folder to view the files created for the calculator app using Django. <br>
![alt text](https://github.com/CAVIND46016/Simple-Calculator-Web-app/blob/master/calculator.png)
